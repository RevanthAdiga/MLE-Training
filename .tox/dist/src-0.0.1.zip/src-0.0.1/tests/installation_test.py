import pytest


def test_installation():

    import pandas
    import numpy
    import sklearn
