import os

import joblib
import pandas as pd
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import logging
import logging.config
from logging_tree import printout
import argparse
import yaml


def get_folder_path(config_path):
    config = read(config_path)
    # print(config)
    data_path = config["folder_path"]
    return data_path


def read(config_path):
    with open(config_path) as yaml_file:
        config = yaml.safe_load(yaml_file)
    return config


parser = argparse.ArgumentParser()
parser.add_argument("--config", help="Enter the folder path", default="config.yaml")
args = parser.parse_args()

housing_path = get_folder_path(config_path=args.config)


LOGGING_DEFAULT_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
        "simple": {"format": "%(message)s"},
    },
    "root": {"level": "DEBUG"},
}


def configure_logger(
    logger=None, cfg=None, log_file=None, console=True, log_level="DEBUG"
):
    """Function to setup configurations of logger through function.

    The individual arguments of `log_file`, `console`, `log_level` will overwrite the ones in cfg.

    Parameters
    ----------
            logger:
                    Predefined logger object if present. If None a ew logger object will be created from root.
            cfg: dict()
                    Configuration of the logging to be implemented by default
            log_file: str
                    Path to the log file for logs to be stored
            console: bool
                    To include a console handler(logs printing in console)
            log_level: str
                    One of `["INFO","DEBUG","WARNING","ERROR","CRITICAL"]`
                    default - `"DEBUG"`

    Returns
    -------
    logging.Logger
    """
    if not cfg:
        logging.config.dictConfig(LOGGING_DEFAULT_CONFIG)
    else:
        logging.config.dictConfig(cfg)

    logger = logger or logging.getLogger()

    if log_file or console:
        for hdlr in logger.handlers:
            logger.removeHandler(hdlr)

        if log_file:
            fh = logging.FileHandler(log_file)
            fh.setLevel(getattr(logging, log_level))
            logger.addHandler(fh)

        if console:
            sh = logging.StreamHandler()
            sh.setLevel(getattr(logging, log_level))
            logger.addHandler(sh)

    return logger

    # configuring and assigning in the logger can be done by the below function


logger = configure_logger(log_file=r"C:\Users\revanth.adiga\Desktop\custom_config.log")
logger.info(f"Logging Test - Start")
# housing_path = input("Enter the directory : ")

test = os.path.join(housing_path, "data/test_set.csv")
testset = pd.read_csv(test)

testx = testset.drop("median_house_value", axis=1)
testy = testset["median_house_value"].copy()

lin = os.path.join(housing_path, "models/lin_reg.pkl")
tree = os.path.join(housing_path, "models/Decision_tree.pkl")
forest = os.path.join(housing_path, "models/Random_Forest.pkl")
svr = os.path.join(housing_path, "models/SVR.pkl")

lin_reg = joblib.load(lin)
predicted_qualities = lin_reg.predict(testx)

print("Linear Regression Scores")
print("  RMSE: %s" % mean_squared_error(testy, predicted_qualities))
print("  MAE: %s" % mean_absolute_error(testy, predicted_qualities))
print("  R2: %s" % r2_score(testy, predicted_qualities))
print("")

tree_reg = joblib.load(tree)
predicted_qualities = tree_reg.predict(testx)

print("Decision Tree Regression Scores")
print("  RMSE: %s" % mean_squared_error(testy, predicted_qualities))
print("  MAE: %s" % mean_absolute_error(testy, predicted_qualities))
print("  R2: %s" % r2_score(testy, predicted_qualities))
print("")

forest_reg = joblib.load(forest)
predicted_qualities = tree_reg.predict(testx)
print("Random Forest Regression Scores")
print("  RMSE: %s" % mean_squared_error(testy, predicted_qualities))
print("  MAE: %s" % mean_absolute_error(testy, predicted_qualities))
print("  R2: %s" % r2_score(testy, predicted_qualities))
print("")

svr_reg = joblib.load(svr)
predicted_qualities = svr_reg.predict(testx)
print("Support Vector Regression Scores")
print("  RMSE: %s" % mean_squared_error(testy, predicted_qualities))
print("  MAE: %s" % mean_absolute_error(testy, predicted_qualities))
print("  R2: %s" % r2_score(testy, predicted_qualities))
print("")
logger.info(f"Logging Test - Test 1 Done")
logger.warning("Watch out!")


# printing out the current loging confiurations being used
printout()

