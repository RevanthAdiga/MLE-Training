import os

import joblib
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.svm import SVR
from sklearn.tree import DecisionTreeRegressor
import argparse
import yaml
import os
import logging
import logging.config
from logging_tree import printout


def get_folder_path(config_path):
    config = read(config_path)
    # print(config)
    data_path = config["folder_path"]
    return data_path


def read(config_path):
    with open(config_path) as yaml_file:
        config = yaml.safe_load(yaml_file)
    return config


parser = argparse.ArgumentParser()
parser.add_argument("--config", help="Enter the folder path", default="config.yaml")
args = parser.parse_args()

housing_path = get_folder_path(config_path=args.config)

# Logging Config
# More on Logging Configuration
# https://docs.python.org/3/library/logging.config.html
# Setting up a config
LOGGING_DEFAULT_CONFIG = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "default": {
            "format": "%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s",
            "datefmt": "%Y-%m-%d %H:%M:%S",
        },
        "simple": {"format": "%(message)s"},
    },
    "root": {"level": "DEBUG"},
}


def configure_logger(
    logger=None, cfg=None, log_file=None, console=True, log_level="DEBUG"
):
    """Function to setup configurations of logger through function.

    The individual arguments of `log_file`, `console`, `log_level` will overwrite the ones in cfg.

    Parameters
    ----------
            logger:
                    Predefined logger object if present. If None a ew logger object will be created from root.
            cfg: dict()
                    Configuration of the logging to be implemented by default
            log_file: str
                    Path to the log file for logs to be stored
            console: bool
                    To include a console handler(logs printing in console)
            log_level: str
                    One of `["INFO","DEBUG","WARNING","ERROR","CRITICAL"]`
                    default - `"DEBUG"`

    Returns
    -------
    logging.Logger
    """
    if not cfg:
        logging.config.dictConfig(LOGGING_DEFAULT_CONFIG)
    else:
        logging.config.dictConfig(cfg)

    logger = logger or logging.getLogger()

    if log_file or console:
        for hdlr in logger.handlers:
            logger.removeHandler(hdlr)

        if log_file:
            fh = logging.FileHandler(log_file)
            fh.setLevel(getattr(logging, log_level))
            logger.addHandler(fh)

        if console:
            sh = logging.StreamHandler()
            sh.setLevel(getattr(logging, log_level))
            logger.addHandler(sh)

    return logger

    # configuring and assigning in the logger can be done by the below function


logger = configure_logger(log_file=r"C:\Users\revanth.adiga\Desktop\custom_config.log")
logger.info(f"Logging Test - Start")
train = os.path.join(housing_path, "data/training_set.csv")
trainset = pd.read_csv(train)

models = os.path.join(housing_path, "models")
os.makedirs(models, exist_ok=True)

trainx = trainset.drop("median_house_value", axis=1)
trainy = trainset["median_house_value"].copy()

test = os.path.join(housing_path, "data/test_set.csv")
testset = pd.read_csv(test)

lin_reg = LinearRegression()
lin_reg.fit(trainx, trainy)
print(lin_reg.score(trainx, trainy))
lin_model = os.path.join(models, "lin_reg.pkl")
joblib.dump(lin_reg, lin_model)

tree_reg = DecisionTreeRegressor()
tree_reg.fit(trainx, trainy)
print(tree_reg.score(trainx, trainy))
tree_model = os.path.join(models, "Decision_tree.pkl")
joblib.dump(tree_reg, tree_model)

forest_reg = RandomForestRegressor(max_features=8, n_estimators=30)
forest_reg.fit(trainx, trainy)
print(forest_reg.score(trainx, trainy))
forest_model = os.path.join(models, "Random_Forest.pkl")
joblib.dump(forest_reg, forest_model)


svr_reg = SVR(C=157055.10989448498, kernel="rbf", gamma=0.26497040005002437)
svr_reg.fit(trainx, trainy)
print(svr_reg.score(trainx, trainy))
svr_model = os.path.join(models, "SVR.pkl")
joblib.dump(svr_reg, svr_model)

logger.info(f"Logging Test - Test 1 Done")
logger.warning("Watch out!")


# printing out the current loging confiurations being used
printout()
