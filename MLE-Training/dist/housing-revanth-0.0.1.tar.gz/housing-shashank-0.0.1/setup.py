from setuptools import find_packages, setup

setup(name="housing-shashank", version="0.0.1", description="House Prices Predictions", author="Shashank C", packages=find_packages(), license="MIT")
